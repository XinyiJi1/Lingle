from django.apps import AppConfig


class LingoowebappConfig(AppConfig):
    name = 'lingooWEBAPP'
